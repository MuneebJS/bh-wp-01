<?php

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Utils;

/**
 *
 * Skill About Widget .
 *
 */
class Techbiz_Skill extends Widget_Base {

	public function get_name() {
		return 'techbizskill';
	}

	public function get_title() {
		return __('Skill', 'techbiz');
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return ['techbiz'];
	}


	protected function register_controls() {


		$this->start_controls_section(
			'style_layout',
			[
				'label' 	=> __('Layout', 'techbiz'),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'skill_about_style',
			[
				'label'   => __('Service Style', 'techbiz'),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => __('Style One', 'techbiz'),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_heading',
			[
				'label' 	=> __('Sec Heading', 'techbiz'),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'section_title',
			[
				'label' 	=> __('Section Title', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Section Title', 'techbiz')
			]
		);
		$this->add_control(
			'section_title_tag',
			[
				'label' 	=> __('Title Tag', 'techbiz'),
				'type' 		=> Controls_Manager::SELECT,
				'options' 	=> [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
				],
				'default' => 'h3',
			]
		);
		$this->add_control(
			'icon_class',
			[
				'label' 	=> __('Section Subtitle Icon Class', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Section Subtitle Icon Class', 'techbiz')
			]
		);
		$this->add_control(
			'section_subtitle',
			[
				'label' 	=> __('Section Subtitle', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Section Subtitle', 'techbiz')
			]
		);

		$this->add_control(
			'section_subtitle_tag',
			[
				'label' 	=> __('Subitle Tag', 'techbiz'),
				'type' 		=> Controls_Manager::SELECT,
				'options' 	=> [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'p'  => 'P',
				],
				'default' 	=> 'h2',
				'condition'	=> ['section_subtitle!' => '']
			]
		);

		$this->add_control(
			'section_description',
			[
				'label' 	=> __('Section Description', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Section Description', 'techbiz')
			]
		);
		$this->add_control(
			'section_description_two',
			[
				'label' 	=> __('Section Description Extra', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Section Description Extra', 'techbiz')
			]
		);

		$this->add_control(
			'count_icon_class',
			[
				'label'   => esc_html__('Count Icon', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('far fa-cube', 'techbiz')
			]
		);
		$this->add_control(
			'count_number',
			[
				'label' 	=> __('Count Number', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('1283k+', 'techbiz')
			]
		);
		$this->add_control(
			'count_title',
			[
				'label' 	=> __('Count Title', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Complete Project', 'techbiz')
			]
		);

		$this->add_control(
			'service_image',
			[
				'label'   => esc_html__('Service Image', 'techbiz'),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'service_image_bg',
			[
				'label'   => esc_html__('Service Bg Image', 'techbiz'),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label' 	=> __('Button Text', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Button Text', 'techbiz')
			]
		);

		$this->add_control(
			'button_url',
			[
				'label' 		=> __('Link', 'techbiz'),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __('https://your-link.com', 'techbiz'),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'skill_about_section',
			[
				'label' 	=> __('Skill', 'techbiz'),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label' 	=> __('Section Description Extra', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Section Description Extra', 'techbiz')
			]
		);
		$repeater->add_control(
			'subtitle',
			[
				'label' 	=> __('Section Subtitle', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Section Subtitle', 'techbiz')
			]
		);
		$repeater->add_control(
			'progress_bar_width',
			[
				'label' 		=> __('Progress Count', 'techbiz'),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> ['%'],
				'range' 		=> [
					'%' 			=> [
						'min' 			=> 0,
						'max' 			=> 100,
						'step'			=> 1,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 41,
				],
			]
		);

		$this->add_control(
			'progress',
			[
				'label'       => __('Progress', 'techbiz'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'       => __('App Development', 'techbiz'),
					],
					[
						'title'       => __('IT Solution', 'techbiz'),
					],
					[
						'title'       => __('IT Consultant', 'techbiz'),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$list = new Repeater();

		$list->add_control(
			'title',
			[
				'label' 	=> __('List Title', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('List Title', 'techbiz')
			]
		);
		$this->add_control(
			'list',
			[
				'label'       => __('List Item', 'techbiz'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $list->get_controls(),
				'default'     => [
					[
						'title'       => __('App Development', 'techbiz'),
					],
					[
						'title'       => __('IT Solution', 'techbiz'),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_style_section',
			[
				'label' => __('Section Title Style', 'techbiz'),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'section_wrapper_margin',
			[
				'label' 		=> __('Section Wrapper Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .title-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'section_wrapper_padding',
			[
				'label' 		=> __('Section Wrapper Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .title-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' 	=> 'after'
			]
		);

		$this->add_control(
			'section_title_color',
			[
				'label' 	=> __('Section Title Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .title-selector' => 'color: {{VALUE}}',
				],
				'condition' => [
					'section_title!'    => ''
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_title_typography',
				'label' 	=> __('Section Title Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .title-selector',
				'condition' => [
					'section_title!'    => ''
				]
			]
		);

		$this->add_responsive_control(
			'section_title_margin',
			[
				'label' 		=> __('Section Title Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .title-selector' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'section_title!'    => ''
				]
			]
		);

		$this->add_responsive_control(
			'section_title_padding',
			[
				'label' 		=> __('Section Title Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .title-selector' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> [
					'section_title!'    => ''
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __('Border', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .title-selector',
				'condition' => [
					'section_title!'    => ''
				],
				'separator' => 'after'
			]
		);

		$this->add_control(
			'section_subtitle_color',
			[
				'label' 		=> __('Section Subtitle Color', 'techbiz'),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .subtitle-selector' => 'color: {{VALUE}}',
				],
				'condition' 	=> [
					'section_subtitle!'    => ''
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_subtitle_typography',
				'label' 	=> __('Section Subtitle Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .subtitle-selector',
				'condition' => [
					'section_subtitle!'    => ''
				],
			]
		);

		$this->add_responsive_control(
			'section_subtitle_margin',
			[
				'label' 		=> __('Section Subtitle Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .subtitle-selector' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'section_subtitle!'    => ''
				],
			]
		);
		$this->add_control(
			'section_description_color',
			[
				'label' 	=> __('Section Description Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .title-area .desc' => 'color: {{VALUE}}',
				],
				'condition' => [
					'section_description!'    => ''
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_description_typography',
				'label' 	=> __('Section Description Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .title-area .desc',
				'condition' => [
					'section_description!'    => ''
				],
			]
		);

		$this->add_responsive_control(
			'section_description_margin',
			[
				'label' 		=> __('Section Description Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .title-area .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> [
					'section_description!'    => ''
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'skill_about_style_section',
			[
				'label' => __('Skill About Style', 'techbiz'),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'skill_about_number_color',
			[
				'label' 	=> __('Skill About Number Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-about .skill-percentage' => 'color: {{VALUE}}!important',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'skill_about_number_typography',
				'label' 	=> __('Skill About Number Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .skill-about .skill-percentage',
			]
		);

		$this->add_control(
			'skill_about_title_color',
			[
				'label' 	=> __('Skill About Title Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-about .skill-title' => 'color: {{VALUE}}!important',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'skill_about_title_typography',
				'label' 	=> __('Skill About Title Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .skill-about .skill-title',
			]
		);

		$this->add_control(
			'skill_about_subtitle_color',
			[
				'label' 	=> __('Skill About SubTitle Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-about .skill-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'skill_about_subtitle_typography',
				'label' 	=> __('Skill About SubTitle Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .skill-about .skill-text',
			]
		);
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		if ('1' == $settings['skill_about_style']) { ?>
			<section class="skills-tbl7 space-top space-extra-bottom">
				<div class="skills-shape"></div>
				<div class="skills-bg" data-bg-src="<?php echo esc_url($settings['service_image_bg']['url']) ?>"></div>
				<div class="container">
					<div class="row">
						<div class="col-xl-6 mb-30">
							<div class="skill-circle2 wow fadeInUp" data-wow-delay="0.2s">
								<?php if (!empty($settings['section_subtitle'])) : ?>
									<<?php echo esc_attr($settings['section_subtitle_tag']); ?> class="sec-subtitle3 subtitle-selector"><i>:-:-:</i> <?php echo wp_kses_post($settings['section_subtitle']) ?></<?php echo esc_attr($settings['section_subtitle_tag']); ?>>
								<?php endif; ?>

								<?php if (!empty($settings['section_title'])) : ?>
									<<?php echo esc_attr($settings['section_title_tag']); ?> class="sec-title3 h1 title-selector"><?php echo wp_kses_post($settings['section_title']) ?></<?php echo esc_attr($settings['section_title_tag']); ?>>
								<?php endif; ?>
								<?php if (!empty($settings['section_description'])) : ?>
									<p class="mb-20"><?php echo wp_kses_post($settings['section_description']) ?></p>
								<?php endif; ?>
								<hr class="skills-divider">
								<div class="counter-box">
									<div class="row">
										<?php foreach ($settings['progress'] as $item) : ?>
											<div class="col-sm-6">
												<div class="circle-column">
													<div class="circle_percent" data-percent="<?php echo esc_attr($item['progress_bar_width']['size']) ?>">
														<div class="circle_inner">
															<div class="round_per"></div>
														</div>
													</div>
													<div class="progress-content">
														<?php if (!empty($item['title'])) : ?>
															<h6 class="progress-title"><?php echo wp_kses_post($item['title']) ?></h6>
														<?php endif; ?>
														<?php if (!empty($item['subtitle'])) : ?>
															<span class="progress-level"><?php echo wp_kses_post($item['subtitle']) ?></span>
														<?php endif; ?>
													</div>
												</div>
											</div>
										<?php endforeach; ?>
									</div>
								</div>
								<div class="row align-items-center">
									<div class="col-lg-8">
										<?php if (!empty($settings['section_description_two'])) {
											echo techbiz_paragraph_tag(array(
												'text'	=> wp_kses_post($settings['section_description_two']),
												'class'	=> 'skill-text'
											));
										} ?>
									</div>
									<?php if (!empty($settings['service_image']['url'])) : ?>
										<div class="col-lg-4">
											<div class="skill-img">
												<?php echo techbiz_img_tag(array(
													'url' => esc_url($settings['service_image']['url']),
												)); ?>
											</div>
										</div>
									<?php endif; ?>
								</div>
								<div class="list-style3 v2">
									<ul>
										<?php foreach ($settings['list'] as $item) : ?>
											<?php if (!empty($item['title'])) : ?>
												<li><i class="far fa-check-circle"></i><?php echo wp_kses_post($item['title']) ?></li>
											<?php endif; ?>

										<?php endforeach; ?>
									</ul>
								</div>

								<?php if (!empty($settings['button_text'])) : ?>
									<div class="d-inline-flex">
										<a href="<?php echo esc_url($settings['button_url']['url']) ?>" <?php esc_attr(!empty($settings['button_url']['is_external']) ? "target=_blank" : ' '); ?> class="vs-btn"> <?php echo wp_kses_post($settings['button_text']) ?></a>
									</div>
								<?php endif; ?>
								<div class="award-box tb7">
									<?php if (!empty($settings['count_icon_class'])) : ?>
										<div class="award-box__icon"><i class="<?php echo esc_attr($settings['count_icon_class']) ?>"></i></div>
									<?php endif; ?>
									<div class="media-body">
										<?php if (!empty($settings['count_number'])) : ?>
											<p class="award-box__number"><?php echo esc_html($settings['count_number']) ?></p>
										<?php endif; ?>
										<?php if (!empty($settings['count_title'])) : ?>
											<div class="award-box__text"><?php echo esc_html($settings['count_title']) ?></div>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
<?php }
	}
}
