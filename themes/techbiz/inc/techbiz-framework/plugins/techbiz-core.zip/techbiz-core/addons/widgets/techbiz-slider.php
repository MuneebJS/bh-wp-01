<?php

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
use \Elementor\Repeater;

/**
 *
 *  Slider Widget .
 *
 */
class Techbiz_Slider extends Widget_Base {

	public function get_name() {
		return 'techbizslider';
	}

	public function get_title() {
		return __(' Slider', 'techbiz');
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return ['techbiz'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'slider_section',
			[
				'label'		 	=> __('Slider', 'techbiz'),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'slider_style',
			[
				'label' 	=> __(' Style', 'techbiz'),
				'type' 		=> Controls_Manager::SELECT,
				'options'   => [
					'1'   		=> __('Style One', 'techbiz'),
				],
				'default'  	=> '1'
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'subtitle',
			[
				'label' 	=> __(' Slider Subtitle', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Subtitle', 'techbiz')
			]
		);
		$repeater->add_control(
			'title',
			[
				'label' 	=> __(' Slider Subtitle', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Title', 'techbiz')
			]
		);
		$repeater->add_control(
			'title_tag',
			[
				'label' 	=> __('Title Tag', 'techbiz'),
				'type' 		=> Controls_Manager::SELECT,
				'options' 	=> [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
				],
				'default' => 'h3',
			]
		);
		$repeater->add_control(
			'info',
			[
				'label' 	=> __('Info', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Info', 'techbiz')
			]
		);
		$repeater->add_control(
			'button_text',
			[
				'label' 	=> __('Button Text', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Button Text', 'techbiz')
			]
		);
		$repeater->add_control(
			'button_link',
			[
				'label' 		=> __('Link', 'techbiz'),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __('https://your-link.com', 'techbiz'),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);
		$repeater->add_control(
			'video_text',
			[
				'label' 	=> __('Button Text', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Button Text', 'techbiz')
			]
		);
		$repeater->add_control(
			'video_link',
			[
				'label' 	=> __('Video Link', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Video Link', 'techbiz')
			]
		);

		$repeater->add_control(
			'social',
			[
				'label' 	=> __('Socal Link', 'techbiz'),
				'type' 		=> Controls_Manager::CODE,
				'default'  	=> __('Socal Link', 'techbiz')
			]
		);

		$repeater->add_control(
			'slider_bg',
			[
				'label'     => __('Background Bg', 'techbiz'),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'slider_shape',
			[
				'label'     => __('Shape One', 'techbiz'),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'arrow_shape',
			[
				'label'     => __('Arrow Shape', 'techbiz'),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [],
			]
		);


		$this->add_control(
			'slider_repeater',
			[
				'label' 		=> __(' Slider', 'techbiz'),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title'    => __('WEB DEVELOPMENT', 'techbiz'),
					],
					[
						'title'    => __('WEB DEVELOPMENT', 'techbiz'),
					],
					[
						'title'    => __('WEB DEVELOPMENT', 'techbiz'),

					],
					[
						'title'    => __('WEB DEVELOPMENT', 'techbiz'),
					],
				],
				'title_field' 	=> '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_style_section',
			[
				'label' => __(' Slider Style', 'techbiz'),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'slider_subtitle_color',
			[
				'label' 	=> __('Sub Title Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hero-content.tb8 .hero-subtitle' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'slider_subtitle_margin',
			[
				'label' 		=> __('Sub Title Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-content.tb8 .hero-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'slider_subtitle_padding',
			[
				'label' 		=> __('Sub Title Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-content.tb8 .hero-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'slider_title_color',
			[
				'label' 	=> __(' Slider Title Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hero-content.tb8 .hero-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'slider_title_typography',
				'label' 	=> __(' Slider Title Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .hero-content.tb8 .hero-title',
			]
		);

		$this->add_responsive_control(
			'slider_title_margin',
			[
				'label' 		=> __(' Slider Title Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-content.tb8 .hero-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'slider_title_padding',
			[
				'label' 		=> __(' Slider Title Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-content.tb8 .hero-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'slider_text_color',
			[
				'label' 	=> __(' Slider Text Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hero-content.tb8 p.hero-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'slider_text_typography',
				'label' 	=> __(' Slider Text Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .hero-content.tb8 p.hero-text',
			]
		);

		$this->add_responsive_control(
			'slider_text_margin',
			[
				'label' 		=> __(' Slider Text Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-content.tb8 p.hero-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'slider_text_padding',
			[
				'label' 		=> __('Slider Text Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-content.tb8 p.hero-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		if (!empty($settings['slider_repeater'])) { ?>
			<section>
				<div class="vs-carousel hero-ltb8" data-slide-show="1" data-fade="true" data-arrows="false" data-dots="true">
					<?php foreach ($settings['slider_repeater'] as $slider) : ?>
						<div>
							<div class="hero-inner">
								<div class="social-media">
									<?php echo wp_kses_post($slider['social']); ?>
								</div>
								<?php echo techbiz_img_tag(array(
									'url'	=> esc_url($slider['slider_shape']['url']),
									'class' => 'hero-shape1',
								)); ?>
								<div class="hero-bg" data-bg-src="<?php echo esc_url($slider['slider_bg']['url']); ?>"></div>
								<div class="hero-content tb8">
									<?php if ($slider['subtitle']) : ?>
										<span class="hero-subtitle"><?php echo wp_kses_post($slider['subtitle']); ?></span>
									<?php endif; ?>
									<?php if ($slider['title']) : ?>
										<<?php echo esc_attr($slider['title_tag']); ?> class="hero-title"><?php echo wp_kses_post($slider['title']); ?></<?php echo esc_attr($slider['title_tag']); ?>>
									<?php endif; ?>
									<?php if ($slider['info']) : ?>
										<p class="hero-text"><?php echo wp_kses_post($slider['info']); ?></p>
									<?php endif; ?>
									<div class="d-flex align-items-center gap-5 flex-wrap">
										<?php if ($slider['button_text'] || $slider['button_link']['url']) : ?>
											<a href="<?php echo esc_attr($slider['button_link']['url']); ?>" class="vs-btn style12"><?php echo wp_kses_post($slider['button_text']); ?></a>
										<?php endif; ?>

										<div class="play-btn-text">
											<a class="play-btn style4 popup-video" href="<?php echo esc_url($slider['video_link']); ?>"><i class="fas fa-play"></i></a>
											<?php echo esc_html($slider['video_text']); ?>
										</div>
									</div>
									<?php if (!empty($slider['arrow_shape']['url'])) : ?>
										<div class="text-md-center pt-3">
											<?php echo techbiz_img_tag(array(
												'url'	=> esc_url($slider['arrow_shape']['url'])
											)); ?>
										</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</section>
<?php }
	}
}
