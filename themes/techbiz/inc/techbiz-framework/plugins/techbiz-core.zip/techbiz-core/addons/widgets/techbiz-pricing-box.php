<?php

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;

/**
 *
 * Pricing Box Widget .
 *
 */
class Techbiz_Pricing_Box extends Widget_Base {

	public function get_name() {
		return 'techbizpricingbox';
	}

	public function get_title() {
		return __('Pricing Box', 'techbiz');
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return ['techbiz'];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'pricing_table_section',
			[
				'label' 	=> __('Pricing Box', 'techbiz'),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'pricing_style',
			[
				'label' 		=> __('Style', 'techbiz'),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  			=> __('Style One', 'techbiz'),
					'2' 			=> __('Style Two', 'techbiz'),
				],
			]
		);


		$repeater = new Repeater();

		$repeater->add_control(
			'package_name',
			[
				'label' 	=> __('Package Name', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Basic Plan', 'techbiz')
			]
		);
		$repeater->add_control(
			'package_discount_text',
			[
				'label' 	=> __('Package Discount Text', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Save 20%', 'techbiz')
			]
		);

		$repeater->add_control(
			'item_description',
			[
				'label'         => __('Description', 'techbiz'),
				'type'          => Controls_Manager::WYSIWYG,
				'default'       => __('Default description', 'techbiz'),
				'placeholder'   => __('Type your description here', 'techbiz'),
			]
		);

		$repeater->add_control(
			'item_price',
			[
				'label' 	=> __('Item Price', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('$27.99', 'techbiz'),
			]
		);

		$repeater->add_control(
			'item_price_time',
			[
				'label' 	=> __('Item Price Time', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('/Month', 'techbiz'),
			]
		);
		$repeater->add_control(
			'feature',
			[
				'label' 	=> __('Feature Title', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('FEATURES:', 'techbiz')
			]
		);
		$repeater->add_control(
			'feature_list',
			[
				'label' 	=> __('Feature List', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Feature List', 'techbiz')
			]
		);

		$repeater->add_control(
			'button_text',
			[
				'label' 	=> __('Button Text', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('Get Started', 'techbiz')
			]
		);

		$repeater->add_control(
			'button_icon_class',
			[
				'label' 	=> __('Button Icon Class', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('far fa-long-arrow-right', 'techbiz'),
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label' 		=> __('Link', 'techbiz'),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __('https://your-link.com', 'techbiz'),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$repeater->add_control(
			'shape',
			[
				'label' 	=> esc_html__('Service Bg Image', 'techbiz'),
				'type' 		=> Controls_Manager::MEDIA,
				'default' 	=> [],
			]
		);

		$this->add_control(
			'slides',
			[
				'label' 		=> __('Slides', 'techbiz'),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'item_price' 			=> __('$54', 'techbiz'),
					],
					[
						'item_price' 			=> __('$99', 'techbiz'),
					],
				],
				'title_field' 	=> '{{{ item_price }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'pricing_table_style_section',
			[
				'label' 	=> __('Pricing Box Style', 'techbiz'),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'project_bg_image',
			[
				'label' 	=> esc_html__('Project Bg Image', 'techbiz'),
				'type' 		=> Controls_Manager::MEDIA,
				'default' 	=> [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'pricing_table_color',
			[
				'label' 		=> __('Pricing Title Color', 'techbiz'),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .price-style1 .price-package,{{WRAPPER}} .price-style2 .price-package' => 'color: {{VALUE}}!important',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'pricing_table_typography',
				'label' 	=> __('Pricing Title Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .price-style1 .price-package,{{WRAPPER}} .price-style2 .price-package',
			]
		);

		$this->add_responsive_control(
			'pricing_table_margin',
			[
				'label' 		=> __('Pricing Title Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .price-style1 .price-package,{{WRAPPER}} .price-style2 .price-package' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'pricing_table_padding',
			[
				'label' 		=> __('Pricing Title Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .price-style1 .price-package,{{WRAPPER}} .price-style2 .price-package' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'		=> 'after',
			]
		);

		$this->add_control(
			'plan_price_color',
			[
				'label' 		=> __('Plan Price Color', 'techbiz'),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .price-style1 .price-amount,{{WRAPPER}} .price-style2 .price-amount' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'plan_price_typography',
				'label' 	=> __('Plan Price Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .price-style1 .price-amount,{{WRAPPER}} .price-style2 .price-amount',
			]
		);

		$this->add_control(
			'plan_list_color',
			[
				'label' 		=> __('Plan List Color', 'techbiz'),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .price-style1 .price-features ul,{{WRAPPER}} .price-style2 .price-features ul li' => 'color: {{VALUE}}',
				],
				'separator'		=> 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'plan_list_typography',
				'label' 	=> __('Plan List Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .price-style1 .price-features ul,{{WRAPPER}} .price-style2 .price-features ul li',
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' 		=> __('Button Color', 'techbiz'),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'color: {{VALUE}}',
				],
				'separator'		=> 'before',
			]
		);

		$this->add_control(
			'button_color_hover',
			[
				'label' 		=> __('Button Color Hover', 'techbiz'),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_bg_color',
			[
				'label' 		=> __('Button Background Color', 'techbiz'),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'button_bg_color_hover',
			[
				'label' 		=> __('Button Background Hover Color', 'techbiz'),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn::before,{{WRAPPER}} .vs-btn::after' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __('Border', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .vs-btn',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __('Button Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .vs-btn',
			]
		);

		$this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __('Button Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __('Button Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __('Button Border Radius', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 		=> 'box_shadow',
				'label' 	=> __('Box Shadow', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .vs-btn',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute('wrapper', 'class', 'row');

		if ("1" == $settings['pricing_style']) {
			echo '<div class="pricing-wrapper">';
			echo '<div class="container">';
			echo '<div ' . $this->get_render_attribute_string('wrapper') . '>';
			foreach ($settings['slides'] as $singleslide) {
				echo '<div class="package-style2 col-md-6 col-xl-12">';
				echo '<div class="package-inner">';
				if (!empty($singleslide['package_discount_text'])) {
					echo '<div class="package-discount">' . esc_html($singleslide['package_discount_text']) . '</div>';
				}
				echo '<div class="package-head">';
				echo '<div class="package-list">';
				if (!empty($singleslide['item_description'])) {
					echo wp_kses_post($singleslide['item_description']);
				}
				echo '</div>';
				echo '</div>';
				echo '<div class="package-body">';
				echo '<div class="package-amount">' . esc_html($singleslide['item_price']) . '<span class="duration">' . esc_html($singleslide['item_price_time']) . '</span></div>';
				if (!empty($singleslide['button_text'])) {
					echo '<a href="' . esc_url($singleslide['button_link']['url']) . '" class="vs-btn style7">' . esc_html($singleslide['button_text']) . '<i class="' . esc_attr($singleslide['button_icon_class']) . '"></i></a>';
				}
				echo '</div>';
				echo '</div>';
				echo '</div>';
			}
			echo '</div>';
			echo '</div>';
			echo '</div>';
		} elseif ("2" == $settings['pricing_style']) { ?>
			<div class="row">
				<?php foreach ($settings['slides'] as $singleslide) : ?>
					<div class="col-xl-4">
						<div class="price-style2">
							<?php if (!empty($singleslide['shape']['url'])) : ?>
								<div class="price-shape">
									<?php echo techbiz_img_tag(array(
										'url'	=> esc_url($singleslide['shape']['url'])
									)); ?>
								</div>
							<?php endif; ?>
							<header class="price-header">
								<?php if (!empty($singleslide['package_name'])) : ?>
									<h3 class="price-package"><?php echo esc_html($singleslide['package_name']); ?></h3>
								<?php endif; ?>
								<div class="price-amount"><span class="price-digit"><?php echo esc_html($singleslide['item_price']); ?></span> <span class="price-duration"><?php echo esc_html($singleslide['item_price_time']); ?></span></div>
							</header>
							<div class="price-body">
								<?php if (!empty($singleslide['package_discount_text'])) : ?>
									<p class="price-text"><?php echo esc_html($singleslide['package_discount_text']); ?></p>
								<?php endif; ?>
								<div class="price-features">
									<?php if (!empty($singleslide['item_description'])) : ?>
										<?php echo wp_kses_post($singleslide['item_description']); ?>
									<?php endif; ?>
								</div>
								<?php if (!empty($singleslide['button_text'])) : ?>
									<a href="<?php echo esc_url($singleslide['button_link']['url']); ?>" class="vs-btn"><?php echo esc_html($singleslide['button_text']); ?></a>
								<?php endif; ?>
								<div class="price-hint">
									<?php if (!empty($singleslide['package_name'])) : ?>
										<h4 class="price-title"><?php echo esc_html($singleslide['feature']); ?></h4>
									<?php endif; ?>
									<?php if (!empty($singleslide['feature_list'])) : ?>
										<?php echo wp_kses_post($singleslide['feature_list']); ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
<?php }
	}
}
