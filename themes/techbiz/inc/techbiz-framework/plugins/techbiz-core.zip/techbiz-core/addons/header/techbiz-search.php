<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Header Widget .
 *
 */
class Techbiz_Search extends Widget_Base {

	public function get_name() {
		return 'techbizsearch';
	}

	public function get_title() {
		return __( 'Search Form', 'techbiz' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'techbiz_header_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'header_search',
			[
				'label' 	=> __( 'Header Search', 'techbiz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'searching_style',
			[
				'label' 	=> __( 'Search Style', 'techbiz' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    '1'   		=> __( 'Style One', 'techbiz' ),
                    '2'   		=> __( 'Style Two', 'techbiz' ),
                ],
                'default'  	=> '1'
			]
        );

		$this->add_control(
			'placeholder_text',
			[
				'label' 		=> __( 'Techbiz Placeholder Text', 'techbiz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default'		=> __( 'Search Here...', 'techbiz' ),
			]
		);

        $this->end_controls_section();

		$this->start_controls_section(
			'search_style',
			[
				'label' 	=> __( 'Style', 'techbiz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'search_background_color',
			[
				'label' 		=> __( 'Search Background Color', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-search button,.icon-btn.style13' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'search_background_color:hover',
			[
				'label' 		=> __( 'Search Background Color HOver', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-btn.style13 i:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .header-search button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();


    }

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['searching_style'] == '1' ){
			echo '<form action="'.esc_url( home_url() ).'" class="header-search">';
				echo '<input name="s" type="text" placeholder="'.esc_attr( $settings['placeholder_text'] ).'">';
				echo '<button type="submit" aria-label="search-button"><i class="far fa-search"></i></button>';
			echo '</form>';
		}elseif( $settings['searching_style'] == '2' ){
			echo '<button class="icon-btn style13 searchBoxTggler"><i class="far fa-search"></i></button>';

			echo '<div class="popup-search-box">';
				echo '<button class="searchClose"><i class="fal fa-times"></i></button>';
				echo '<form action="'.esc_url( home_url() ).'">';
					echo '<input type="text" class="border-theme" placeholder="'.esc_attr( $settings['placeholder_text'] ).'">';
					echo '<button type="submit"><i class="fal fa-search"></i></button>';
				echo '</form>';
			echo '</div>';
		}
	}

}