<?php

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;

/**
 *
 * Hero Banner Widget .
 *
 */
class Techbiz_Hero_Banner extends Widget_Base
{

	public function get_name()
	{
		return 'techbizherobanner';
	}

	public function get_title()
	{
		return __('Hero Banner', 'techbiz');
	}

	public function get_icon()
	{
		return 'eicon-code';
	}

	public function get_categories()
	{
		return ['techbiz'];
	}

	protected function register_controls()
	{

		$this->start_controls_section(
			'about_us_section',
			[
				'label'		 	=> __('Hero Banner', 'techbiz'),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'section_description',
			[
				'label' 	=> __('Section Title With Description', 'techbiz'),
				'type' 		=> Controls_Manager::WYSIWYG,
				'default'  	=> __('Section Title With Description', 'techbiz')
			]
		);

		$this->add_control(
			'video_url',
			[
				'label' 		=> __('Link', 'techbiz'),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __('https://your-link.com', 'techbiz'),
				'show_external' => false,
				'default' 		=> [
					'url' 			=> 'https://www.youtube.com/watch?v=_sI_Ps7JSEk',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);
		$this->add_control(
			'banner_circle_shape',
			[
				'label' 		=> __('Circle Text', 'techbiz'),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'banner_circle_shape_hover',
			[
				'label' 		=> __('Circle Text Hover', 'techbiz'),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'banner_shape_one',
			[
				'label' 		=> __('Shape One', 'techbiz'),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [],
			]
		);
		$this->add_control(
			'banner_shape_two',
			[
				'label' 		=> __('Shape Two', 'techbiz'),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [],
			]
		);

		$this->end_controls_section();

		// style tab
		$this->start_controls_section(
			'about_us_style_section',
			[
				'label' => __('Hero Banner Style', 'techbiz'),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'section_bg_color',
			[
				'label' 	=> __('Section Background Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hero-ltb7' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'section_title_color',
			[
				'label' 	=> __('Section Title Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hero-content.tb7 .hero-title' => 'color: {{VALUE}}',
				],
				'condition' => [
					'section_description!'    => ''
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_title_typography',
				'label' 	=> __('Section Title Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .hero-content.tb7 .hero-title',
				'condition' => [
					'section_description!'    => ''
				]
			]
		);

		$this->add_responsive_control(
			'section_title_margin',
			[
				'label' 		=> __('Section Title Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-content.tb7 .hero-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'section_description!'    => ''
				]
			]
		);

		$this->add_responsive_control(
			'section_title_padding',
			[
				'label' 		=> __('Section Title Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-content.tb7 .hero-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> [
					'section_description!'    => ''
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __('Border', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .hero-content.tb7 .hero-title',
				'condition' => [
					'section_description!'    => ''
				],
				'separator' => 'after'
			]
		);

		$this->end_controls_section();
	}

	protected function render()
	{

		$settings = $this->get_settings_for_display();
?>
		<div class="vs-carousel hero-ltb7" data-slide-show="1" data-fade="true" data-arrows="false">
			<div>
				<div class="hero-inner">
					<?php if (!empty($settings['banner_shape_one']['url'])) : ?>
						<div class="hero-shape1">
							<?php
							echo techbiz_img_tag(array(
								'url'   => esc_url($settings['banner_shape_one']['url'])
							)); ?>
						</div>
					<?php endif; ?>
					<?php if (!empty($settings['banner_shape_two']['url'])) : ?>
						<div class="hero-shape2">
							<?php
							echo techbiz_img_tag(array(
								'url'   => esc_url($settings['banner_shape_two']['url'])
							)); ?>
						</div>
					<?php endif; ?>
					<div class="container">
						<div class="row">
							<div class="col-auto">
								<div class="hero-content tb7">
									<?php if (!empty($settings['section_description'])) : ?>
										<h1 class="hero-title"><?php echo wp_kses_post($settings['section_description']); ?></h1>
									<?php endif; ?>
									<?php if (!empty($settings['video_url']['url'])) : ?>
										<a class="tb-play-btn popup-video" href="<?php echo esc_url($settings['video_url']['url']); ?>">
											<?php if (!empty($settings['banner_circle_shape']['url'])) : ?>
												<span class="text1">
													<?php
													echo techbiz_img_tag(array(
														'url'   => esc_url($settings['banner_circle_shape']['url'])
													)); ?>
												</span>
											<?php endif; ?>
											<span class="play-icon">
												<svg width="41" height="46" viewBox="0 0 41 46" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M40.5874 23L0.587404 46L0.587406 -1.74846e-06L40.5874 23Z" fill="#0E5AF2" />
												</svg>
											</span>
											<?php if (!empty($settings['banner_circle_shape_hover']['url'])) : ?>
												<span class="text2">
													<?php
													echo techbiz_img_tag(array(
														'url'   => esc_url($settings['banner_circle_shape_hover']['url'])
													)); ?>
												</span>
											<?php endif; ?>
										</a>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php
	}
}
