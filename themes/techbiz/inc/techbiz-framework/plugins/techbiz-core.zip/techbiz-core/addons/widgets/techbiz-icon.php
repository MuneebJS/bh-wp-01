<?php

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;

/**
 *
 * Image Widget .
 *
 */
class Techbiz_Icon extends Widget_Base {

	public function get_name() {
		return 'techbiiconbox';
	}

	public function get_title() {
		return __('Icon Box', 'techbiz');
	}


	public function get_icon() {
		return 'eicon-code';
	}


	public function get_categories() {
		return ['techbiz'];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' 	=> __('Contnet', 'techbiz'),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __('Title', 'bizino'),
				'type'         => Controls_Manager::TEXTAREA,
				'default'   => __('Website', 'techbiz'),
			]
		);

		$this->add_control(
			'icon',
			[
				'label' 		=> __('Icon', 'techbiz'),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display(); ?>

		<div class="offer-style">
			<?php if (!empty($settings['title'])) : ?>
				<h3 class="h5 offer-title"><?php echo wp_kses_post($settings['title']) ?></h3>
			<?php endif; ?>
			<?php if (!empty($settings['icon']['url'])) : ?>
				<i class="offer-icon">
					<?php echo techbiz_img_tag(array(
						'url' => esc_url($settings['icon']['url']),
					)); ?>
				</i>
			<?php endif; ?>
		</div>
<?php }
}
