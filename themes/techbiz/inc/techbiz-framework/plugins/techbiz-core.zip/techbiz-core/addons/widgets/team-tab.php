<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Team Widget .
 *
 */
class Techbiz_Team_Member_Tab extends Widget_Base {

	public function get_name() {
		return 'techbizteammembertab';
	}

	public function get_title() {
		return __( 'Team Member Tab', 'techbiz' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'techbiz' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'image_section',
			[
				'label'     => __( 'Team Member', 'techbiz' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		$repeater = new Repeater();

        $repeater->add_control(
			'team_member_image',
			[
				'label'     => __( 'Team Member Image', 'techbiz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
        $repeater->add_control(
			'person_name',
            [
				'label'         => __( 'Person Name', 'techbiz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'John Steven' , 'techbiz' ),
				'label_block'   => true,
			]
		);
		$repeater->add_control(
			'person_details_url',
			[
				'label' 		=> __( 'Person Details Url', 'techbiz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'techbiz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);
        $repeater->add_control(
			'person_designation',
            [
				'label'         => __( 'Person Designation', 'techbiz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Founder' , 'techbiz' ),
				'label_block'   => true,
			]
		);

        $repeater->add_control(
			'person_about_text',
            [
				'label'         => __( 'Person About Text', 'techbiz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Write About Text' , 'techbiz' ),
				'label_block'   => true,
			]
		);

        $repeater->add_control(
			'follow_text',
            [
				'label'         => __( 'Follow Text', 'techbiz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Follow Now' , 'techbiz' ),
				'label_block'   => true,
			]
		);

		$repeater->add_control(
			'social_icon_one',
			[
				'label' 		=> __( 'Social Icon One', 'techbiz' ),
				'type' 			=> Controls_Manager::ICONS,
				'default' 		=> [
					'value' 		=> 'fab fa-facebook-f',
					'library' 		=> 'solid',
				],
			]
		);
		$repeater->add_control(
			'social_icon_one_link',
			[
				'label' 		=> __( 'Social Icon Link One', 'techbiz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'techbiz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> 'www.facebook.com',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);
		$repeater->add_control(
			'social_icon_two',
			[
				'label' 		=> __( 'Social Icon Two', 'techbiz' ),
				'type' 			=> Controls_Manager::ICONS,
				'default' 		=> [
					'value' 		=> 'fab fa-twitter',
					'library' 		=> 'solid',
				],
			]
		);
		$repeater->add_control(
			'social_icon_two_link',
			[
				'label' 		=> __( 'Social Icon Link Two', 'techbiz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'techbiz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> 'www.twitter.com',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);
		$repeater->add_control(
			'social_icon_three',
			[
				'label' 		=> __( 'Social Icon Three', 'techbiz' ),
				'type' 			=> Controls_Manager::ICONS,
				'default' 		=> [
					'value' 		=> 'fab fa-instagram',
					'library' 		=> 'solid',
				],
			]
		);
		$repeater->add_control(
			'social_icon_three_link',
			[
				'label' 		=> __( 'Social Icon Link Three', 'techbiz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'techbiz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> 'www.instagram.com',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);
		$repeater->add_control(
			'social_icon_four',
			[
				'label' 		=> __( 'Social Icon Four', 'techbiz' ),
				'type' 			=> Controls_Manager::ICONS,
				'default' 		=> [
					'value' 		=> 'fab fa-instagram',
					'library' 		=> 'solid',
				],
			]
		);
		$repeater->add_control(
			'social_icon_four_link',
			[
				'label' 		=> __( 'Social Icon Link Four', 'techbiz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'techbiz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> 'www.instagram.com',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);
		$repeater->add_control(
			'social_icon_five',
			[
				'label' 		=> __( 'Social Icon Five', 'techbiz' ),
				'type' 			=> Controls_Manager::ICONS,
				'default' 		=> [
					'value' 		=> 'fab fa-instagram',
					'library' 		=> 'solid',
				],
			]
		);
		$repeater->add_control(
			'social_icon_five_link',
			[
				'label' 		=> __( 'Social Icon Link Five', 'techbiz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'techbiz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> 'www.instagram.com',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);

        $repeater->add_control(
			'email_text',
            [
				'label'         => __( 'Email Text', 'techbiz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'EMAIL HERE:' , 'techbiz' ),
				'label_block'   => true,
			]
		);

        $repeater->add_control(
			'email',
            [
				'label'         => __( 'Email', 'techbiz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'info@example.com' , 'techbiz' ),
				'label_block'   => true,
			]
		);

        $repeater->add_control(
			'button_text',
            [
				'label'         => __( 'Button Text', 'techbiz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Contact Now' , 'techbiz' ),
				'label_block'   => true,
			]
		);

        $repeater->add_control(
			'button_url',
            [
				'label'         => __( 'Button URL?', 'techbiz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '#' , 'techbiz' ),
				'label_block'   => true,
			]
		);

		$this->add_control(
			'slides',
			[
				'label' 		=> __( 'Team Member', 'techbiz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'image' 	=> Utils::get_placeholder_image_src(),
					],
					[
						'image' 	=> Utils::get_placeholder_image_src(),
					],
				],
				'title_field' 	=> '{{person_name}}',
			]
		);

        $this->end_controls_section();

		$this->start_controls_section(
			'general',
			[
				'label' 	=> __( 'General', 'techbiz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'social_icon_color',
			[
				'label' 		=> __( 'Social Icon Color', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .team-layout6 .team-social a' => 'color: {{VALUE}}',
                ]
			]
        );

		$this->add_control(
			'social_icon_hover_color',
			[
				'label' 		=> __( 'Social Icon Hover Color', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .team-layout6 .team-social a:hover i' => 'color: {{VALUE}}',
                ]
			]
        );

		$this->add_control(
			'social_icon_bg_color',
			[
				'label' 		=> __( 'Social Icon Bg Color', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .team-layout6 .team-social a' => 'background-color: {{VALUE}}',
                ]
			]
        );

		$this->add_control(
			'team_text_color',
			[
				'label' 		=> __( 'Team Text Color', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .team-layout6 .team-box .team-text' => 'color: {{VALUE}}',
                ]
			]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'team_member_style_option',
			[
				'label' 	=> __( 'Team Member Style', 'techbiz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'person_name_color',
			[
				'label' 		=> __( 'Person Name Color', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .team-layout6 .team-box .team-title,{{WRAPPER}} .team-layout6 .team-style6 .team-title' => 'color: {{VALUE}}',
                ]
			]
        );
		$this->add_control(
			'person_name_color_hover',
			[
				'label' 		=> __( 'Person Name Color Hover', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .team-layout6 .team-box .team-title a:hover,{{WRAPPER}} .team-layout6 .team-style6 .team-title:hover' => 'color: {{VALUE}}',
                ]
			]
        );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'person_name_typography',
				'label'         => __( 'Person Name Typography', 'techbiz' ),
                'selector'      => '{{WRAPPER}} .team-layout6 .team-box .team-title,{{WRAPPER}} .team-layout6 .team-style6 .team-title',
			]
		);
        $this->add_responsive_control(
			'person_name_margin',
			[
				'label'         => __( 'Person Name Margin', 'techbiz' ),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%', 'em' ],
				'selectors'     => [
					'{{WRAPPER}} .team-layout6 .team-box .team-title,{{WRAPPER}} .team-layout6 .team-style6 .team-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->add_responsive_control(
			'person_name_padding',
			[
				'label'         => __( 'Person Name Padding', 'techbiz' ),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%', 'em' ],
				'selectors'     => [
					'{{WRAPPER}} .team-layout6 .team-box .team-title,{{WRAPPER}} .team-layout6 .team-style6 .team-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
				'separator'		=> 'after',
			]
		);
		$this->add_control(
			'person_designation_color',
			[
				'label' 		=> __( 'Person Designation Color', 'techbiz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .team-layout6 .team-box .team-degi,{{WRAPPER}} .team-style6 .team-degi' => 'color: {{VALUE}}',
                ]
			]
        );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'person_designation_typography',
				'label'         => __( 'Person Designation Typography', 'techbiz' ),
                'selector'      => '{{WRAPPER}} .team-layout6 .team-box .team-degi,{{WRAPPER}} .team-style6 .team-degi',
			]
		);
        $this->add_responsive_control(
			'person_designation_margin',
			[
				'label'         => __( 'Person Designation Margin', 'techbiz' ),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%', 'em' ],
				'selectors'     => [
					'{{WRAPPER}} .team-layout6 .team-box .team-degi,{{WRAPPER}} .team-style6 .team-degi' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->add_responsive_control(
			'person_designation_padding',
			[
				'label'         => __( 'Person Designation Padding', 'techbiz' ),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%', 'em' ],
				'selectors'     => [
					'{{WRAPPER}} .team-layout6 .team-box .team-degi,{{WRAPPER}} .team-style6 .team-degi' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
		);
		$this->end_controls_section();

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( ! empty( $settings['slides'] ) ){
			echo '<section class="team-layout6">';
				echo '<div class="container wow fadeInUp" data-wow-delay="0.2s">';
					echo '<div class="row g-5">';
						echo '<div class="col-xl-auto">';
							$x = 0;
							foreach( $settings['slides'] as $team_member ){
								if( $x == 0 ){
									$activeclass = "active";
								}else{
									$activeclass = "";
								}
								echo '<div class="team-style6 '.$activeclass.'" data-tab-target="#tab'.$x.'">';
									if( ! empty( $team_member['team_member_image']['url'] ) ){
										echo '<div class="team-img">';
											echo techbiz_img_tag( array(
												'url'	=> esc_url( $team_member['team_member_image']['url'] ),
											) );
										echo '</div>';
									}
									echo '<div class="team-content">';
										if( ! empty( $team_member['person_name'] ) ){
											echo '<h3 class="team-title">'.esc_html( $team_member['person_name'] ).'</h3>';
										}
										if( ! empty( $team_member['person_designation'] ) ){
											echo '<p class="team-degi">'.esc_html( $team_member['person_designation'] ).'</p>';
										}
									echo '</div>';
								echo '</div>';
								$x++;
							}
						echo '</div>';

						echo '<div class="col">';
							$x = 0;
							foreach( $settings['slides'] as $team_member ){
								if( $x == 0 ){
									$activeclass = "active";
								}else{
									$activeclass = "";
								}
								$target_team 	= $team_member['person_details_url']['is_external'] ? ' target="_blank"' : '';
								$nofollow_team 	= $team_member['person_details_url']['nofollow'] ? ' rel="nofollow"' : '';
								// Icon One
								$target_social_one 		= $team_member['social_icon_one_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow_social_one 	= $team_member['social_icon_one_link']['nofollow'] ? ' rel="nofollow"' : '';
								// Icon Two
								$target_social_two 		= $team_member['social_icon_two_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow_social_two 	= $team_member['social_icon_two_link']['nofollow'] ? ' rel="nofollow"' : '';
								// Icon Three
								$target_social_three 	= $team_member['social_icon_three_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow_social_three 	= $team_member['social_icon_three_link']['nofollow'] ? ' rel="nofollow"' : '';
								// Icon Four
								$target_social_four 	= $team_member['social_icon_four_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow_social_four 	= $team_member['social_icon_four_link']['nofollow'] ? ' rel="nofollow"' : '';
								// Icon Five
								$target_social_five 	= $team_member['social_icon_five_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow_social_five 	= $team_member['social_icon_five_link']['nofollow'] ? ' rel="nofollow"' : '';
								echo '<div id="tab'.$x.'" class="team-box '.$activeclass.'" data-tab-content>';
									echo '<div class="row">';
										echo '<div class="col-lg-5">';
											if( ! empty( $team_member['team_member_image']['url'] ) ){
												echo '<div class="team-img">';
													echo techbiz_img_tag( array(
														'url'	=> esc_url( $team_member['team_member_image']['url'] ),
													) );
												echo '</div>';
											}
										echo '</div>';
										echo '<div class="col-lg-7">';
											echo '<div class="team-body">';
												echo '<div class="team-content">';
													if( ! empty( $team_member['person_name'] ) ){
														echo '<h3 class="team-title"><a class="text-inherit" href="'.esc_url( $team_member['person_details_url']['url'] ).'">'.esc_html( $team_member['person_name'] ).'</a></h3>';
													}
													if( ! empty( $team_member['person_designation'] ) ){
														echo '<p class="team-degi">'.esc_html( $team_member['person_designation'] ).'</p>';
													}
													if( ! empty( $team_member['person_about_text'] ) ){
														echo '<p class="team-text">';
															echo wp_kses_post( $team_member['person_about_text'] );
														echo '</p>';
													}
												echo '</div>';
												echo '<div class="team-contact">';
													echo '<div class="contact-social">';
														if( ! empty( $team_member['follow_text'] ) ){
															echo '<span class="title">'.esc_html( $team_member['follow_text'] ).'</span>';
														}
														echo '<div class="team-social">';
															if( !empty( $team_member['social_icon_one']['value'] ) ){
																echo '<a '.wp_kses_post( $target_social_one.$nofollow_social_one ).' href="'.esc_url( $team_member['social_icon_one_link']['url'] ).'"><i class="'.esc_attr( $team_member['social_icon_one']['value'] ).'"></i></a>';
															}
															if( !empty( $team_member['social_icon_two']['value'] ) ){
																echo '<a '.wp_kses_post( $target_social_two.$nofollow_social_two ).' href="'.esc_url( $team_member['social_icon_two_link']['url'] ).'"><i class="'.esc_attr( $team_member['social_icon_two']['value'] ).'"></i></a>';
															}
															if( !empty( $team_member['social_icon_three']['value'] ) ){
																echo '<a '.wp_kses_post( $target_social_three.$nofollow_social_three ).' href="'.esc_url( $team_member['social_icon_three_link']['url'] ).'"><i class="'.esc_attr( $team_member['social_icon_three']['value'] ).'"></i></a>';
															}
															if( !empty( $team_member['social_icon_four']['value'] ) ){
																echo '<a '.wp_kses_post( $target_social_four.$nofollow_social_four ).' href="'.esc_url( $team_member['social_icon_four_link']['url'] ).'"><i class="'.esc_attr( $team_member['social_icon_four']['value'] ).'"></i></a>';
															}
															if( !empty( $team_member['social_icon_five']['value'] ) ){
																echo '<a '.wp_kses_post( $target_social_five.$nofollow_social_five ).' href="'.esc_url( $team_member['social_icon_five_link']['url'] ).'"><i class="'.esc_attr( $team_member['social_icon_five']['value'] ).'"></i></a>';
															}
														echo '</div>';
													echo '</div>';
													echo '<div class="contact-email">';
														if( ! empty( $team_member['email_text'] ) ){
															echo '<span class="title">'.esc_html( $team_member['email_text'] ).'</span>';
														}
														$email 			= is_email( $team_member['email'] );
														$replace 		= array(' ','-',' - ');
														$with 			= array('','','');
														$emailurl 		= str_replace( $replace, $with, $email );
														echo '<p class="info"><i class="fal fa-envelope"></i><a href="mailto:'.esc_attr( $emailurl ).'">'.esc_html( $email ).'</a></p>';

													echo '</div>';
												echo '</div>';
												if( ! empty( $team_member['button_text'] ) ){
													echo '<a href="'.esc_url( $team_member['button_url'] ).'" class="vs-btn">'.esc_html( $team_member['button_text'] ).'<i class="far fa-arrow-right"></i></a>';
												}
											echo '</div>';
										echo '</div>';
									echo '</div>';
								echo '</div>';
								$x++;
							}
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</section>';
		}
	}
}