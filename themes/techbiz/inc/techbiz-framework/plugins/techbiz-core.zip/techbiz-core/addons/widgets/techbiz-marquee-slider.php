<?php

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Css_Filter;
use \Elementor\Utils;
use \Elementor\Repeater;

/**
 *
 * Marquee Slider Widget .
 *
 */
class Techbiz_Marquee_Slider extends Widget_Base {

	public function get_name() {
		return 'techbizmarqueeslider';
	}

	public function get_title() {
		return __('Marquee Slider', 'techbiz');
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return ['techbiz'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'marquee_section',
			[
				'label'		 	=> __('Marquee Slider', 'techbiz'),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'marquee_style',
			[
				'label' 	=> __('Marquee Style', 'techbiz'),
				'type' 		=> Controls_Manager::SELECT,
				'options'   => [
					'1'   		=> __('Style One', 'techbiz'),
					'2'   		=> __('Style Two', 'techbiz'),
				],
				'default'  	=> '1'
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'marquee_text',
			[
				'label' 	=> __('Marquee Slider Text', 'techbiz'),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __('WEB DEVELOPMENT', 'techbiz')
			]
		);
		$repeater->add_control(
			'marquee_icon',
			[
				'label'     => __('Marquee Icon', 'techbiz'),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [],
			]
		);

		$this->add_control(
			'marquee_repeater',
			[
				'label' 		=> __('Marquee Slider', 'techbiz'),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'marquee_text'    => __('WEB DEVELOPMENT', 'techbiz'),
					],
					[
						'marquee_text'    => __('WEB DEVELOPMENT', 'techbiz'),
					],
					[
						'marquee_text'    => __('WEB DEVELOPMENT', 'techbiz'),

					],
					[
						'marquee_text'    => __('WEB DEVELOPMENT', 'techbiz'),
					],
				],
				'title_field' 	=> '{{{ marquee_text }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'marquee_style_section',
			[
				'label' => __('Marquee Slider Style', 'techbiz'),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' 		=> 'background',
				'label' 	=> __('Background', 'techbiz'),
				'types' 	=> ['classic', 'gradient', 'video'],
				'selector' 	=> '{{WRAPPER}} .el-marquee-section'
			]
		);
		$this->add_responsive_control(
			'marquee_bg_margin',
			[
				'label' 		=> __('Marquee Box Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .marquee' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'marquee_bg_padding',
			[
				'label' 		=> __('Marquee Box Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .marquee' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'marquee_text_color',
			[
				'label' 	=> __('Marquee Slider Text Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .marquee .marquee-text' => 'color: {{VALUE}}',
				],
				'condition'	=> [
					'marquee_style' => ['1']
				]
			]
		);
		$this->add_control(
			'marquee_stock_color',
			[
				'label' 	=> __('Marquee Slider Text Color', 'techbiz'),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .marquee .marquee-text' => '-webkit-text-stroke-color: {{VALUE}}',
				],
				'condition'	=> [
					'marquee_style' => ['2']
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'marquee_text_typography',
				'label' 	=> __('Marquee Slider Text Typography', 'techbiz'),
				'selector' 	=> '{{WRAPPER}} .marquee .marquee-text',
			]
		);

		$this->add_responsive_control(
			'marquee_text_margin',
			[
				'label' 		=> __('Marquee Slider Text Margin', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .marquee .marquee-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'marquee_text_padding',
			[
				'label' 		=> __('Marquee Slider Text Padding', 'techbiz'),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> ['px', '%', 'em'],
				'selectors' 	=> [
					'{{WRAPPER}} .marquee .marquee-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		if (!empty($settings['marquee_repeater'])) : ?>
			<?php if ('1' == $settings['marquee_style']) : ?>
				<section class="marquee-style1 el-marquee-section">
					<div class='marquee el-marquee-section' data-duration='10000' data-gap='10' data-duplicated='false'>
						<?php foreach ($settings['marquee_repeater'] as $item) : ?>
							<?php if (!empty($item['marquee_icon']['url'])) : ?>
								<div>
									<?php echo techbiz_img_tag(array(
										'url'	=> esc_url($item['marquee_icon']['url']),
									)); ?>
								</div>
							<?php endif; ?>
							<?php if (!empty($item['marquee_text'])) : ?>
								<div class="marquee-text"><?php echo esc_html($item['marquee_text']); ?></div>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>
				</section>
			<?php elseif ('2' == $settings['marquee_style']) : ?>
				<section class="marquee-style2 overflow-hidden el-marquee-section">
					<div class='marquee el-marquee-section' data-duration='10000' data-gap='10' data-duplicated='false'>
						<?php foreach ($settings['marquee_repeater'] as $item) : ?>
							<?php if (!empty($item['marquee_icon']['url'])) : ?>
								<div>
									<?php echo techbiz_img_tag(array(
										'url'	=> esc_url($item['marquee_icon']['url']),
									)); ?>
								</div>
							<?php endif; ?>
							<?php if (!empty($item['marquee_text'])) : ?>
								<div class="marquee-text"><?php echo esc_html($item['marquee_text']); ?></div>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>
				</section>
			<?php endif; ?>
<?php endif;
	}
}
