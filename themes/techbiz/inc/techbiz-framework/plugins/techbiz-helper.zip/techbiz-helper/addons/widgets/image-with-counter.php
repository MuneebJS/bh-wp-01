<?php

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

/**
 *
 * Image with Counter Widget .
 *
 */
class Bizino_Image_Counter_Widget extends Widget_Base {

    public function get_name() {
        return 'bizinoimagewithcounter';
    }

    public function get_title() {
        return __('Bizino Image with Counter', 'bizino');
    }


    public function get_icon() {
        return 'eicon-image-hotspot';
    }


    public function get_categories() {
        return ['bizino'];
    }


    protected function register_controls() {

        $this->start_controls_section(
            'image_section',
            [
                'label' => __('Image', 'bizino'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'layout_styles',
            [
                'label' => __('Layout Styles', 'bizino'),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '1' => __('Style One', 'bizino'),
                ],
            ]
        );
        $this->add_control(
            'image',
            [
                'label' => __('Choose Image', 'bizino'),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'image2',
            [
                'label' => __('Choose Image 2', 'bizino'),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'shape',
            [
                'label' => __('Choose Shape', 'bizino'),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'counter',
            [
                'label' => __('Counter', 'bizino'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'bizino'),
                'label_off' => __('No', 'bizino'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __('Choose Shape', 'bizino'),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition'    => [
                    'counter' => ['yes']
                ]
            ]
        );

        $this->add_control(
            'count',
            [
                'label' => __('Count', 'bizino'),
                'type'         => Controls_Manager::TEXTAREA,
                'default'   => __('30+', 'techbiz'),
                'condition'    => [
                    'counter' => ['yes']
                ]
            ]
        );

        $this->add_control(
            'title',
            [
                'label'     => __('Title', 'techbiz'),
                'type'         => Controls_Manager::TEXTAREA,
                'default'   => __('YEAR EXPERIENCE', 'techbiz'),
                'condition'    => [
                    'counter' => ['yes']
                ]
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'video_btn_style_section',
            [
                'label' => __('Counter Button Style', 'bizino'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['video_btn' => 'yes']
            ]
        );

        $this->add_control(
            'video_btn_color',
            [
                'label' => __('Counter Button Color', 'bizino'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn i' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_control(
            'video_btn_hover_color',
            [
                'label' => __('Counter Button Hover Color', 'bizino'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn:hover i' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_control(
            'video_btn_background_color',
            [
                'label' => __('Counter Button Background Color', 'bizino'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn i' => 'background-color: {{VALUE}}',
                ]
            ]
        );

        $this->add_control(
            'video_btn_background_hover_color',
            [
                'label' => __('Counter Button Background Hover Color', 'bizino'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn:hover i' => 'background-color: {{VALUE}}',
                ]
            ]
        );

        $this->add_control(
            'video_btn_ripple_effect_color',
            [
                'label' => __('Counter Button Ripple Effect Color', 'bizino'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn:after,{{WRAPPER}} .play-btn:before' => 'background-color: {{VALUE}}!important;',
                ]
            ]
        );
        $this->add_responsive_control(
            'cta_video',
            [
                'label' => __('Margin', 'bizino'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .cta-video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        if ($settings['layout_styles'] == '1') { ?>
            <div class="img-box3 tb8">
                <?php if (!empty($settings['shape']['url'])) : ?>
                    <div class="shape">
                        <?php echo techbiz_img_tag(array(
                            'url' => esc_url($settings['shape']['url']),
                        )); ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($settings['image']['url'])) : ?>
                    <div class="img-1">
                        <?php echo techbiz_img_tag(array(
                            'url' => esc_url($settings['image']['url']),
                        )); ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($settings['image2']['url'])) : ?>
                    <div class="img-2">
                        <?php echo techbiz_img_tag(array(
                            'url' => esc_url($settings['image2']['url']),
                        )); ?>
                    </div>
                <?php endif; ?>
                <div class="award-box tb8">
                    <?php if (!empty($settings['icon']['url'])) : ?>
                        <div class="award-box__icon">
                            <?php echo techbiz_img_tag(array(
                                'url' => esc_url($settings['icon']['url']),
                            )); ?>
                        </div>
                    <?php endif; ?>
                    <div class="media-body">
                        <p class="award-box__number"><?php echo esc_html($settings['count']) ?></p>
                        <div class="award-box__text"><?php echo esc_html($settings['title']) ?></div>
                    </div>
                </div>
            </div>
<?php }
    }
}

Plugin::instance()->widgets_manager->register(new Bizino_Image_Counter_Widget());
